-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")
local wilder = require("wilder")
wilder.setup({ modes = { ":", "/", "?" } })

require("lualine").setup({
  options = {
    theme = "catppuccin",
    -- ... the rest of your lualine config
  },
})

require("telescope").load_extension("emoji")
require("iron.core")
require("catppuccin").setup({
  integrations = {
    cmp = true,
    gitsigns = true,
    nvimtree = true,
    treesitter = true,
    notify = true,
    markdown = true,
    dap_ui = true,
    dap = true,
    mini = {
      enabled = true,
      indentscope_color = "",
    },
  },
})

vim.cmd.colorscheme("catppuccin-mocha")
vim.g.python3_host_prog = "$HOME/miniforge3/bin/python"
-- require("lspconfig").pyright.setu:
