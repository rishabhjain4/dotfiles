return {
  "gelguy/wilder.nvim",
  config = function()
    -- config goes here
  end,
}
