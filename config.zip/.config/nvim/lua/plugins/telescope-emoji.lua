return {
  "xiyaowong/telescope-emoji.nvim",
}
