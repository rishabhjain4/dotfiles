# pod

This plugin adds completion for [`CocoaPods`](https://cocoapods.org/).
CocoaPods is a dependency manager for Swift and Objective-C Cocoa projects.

To use it, add `pod` to the plugins array in your zshrc file:

```zsh
plugins=(... pod)
```
