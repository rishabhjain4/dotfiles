alias ma='mongocli atlas'
alias mcm='mongocli cloud-manager'
alias mom='mongocli ops-manager'
alias miam='mongocli iam'
